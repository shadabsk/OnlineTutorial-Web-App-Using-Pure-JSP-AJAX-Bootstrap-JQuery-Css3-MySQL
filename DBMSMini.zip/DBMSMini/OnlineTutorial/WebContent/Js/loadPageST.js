$(document).ready(function(){
	$("#StPF").on("click",function(){
		$("#content").load("StudentPF.jsp");
	});
});

$(document).ready(function(){
	$("#StMM").on("click",function(){
		$("#content").load("CurrentCourse.jsp");
	});
});

			