$(document).ready(function(){
	$("#AdPF").on("click",function(){
		$("#content").load("AdminPF.jsp");
	});
});

$(document).ready(function(){
	$("#AdFC").on("click",function(){
		$("#content").load("AdminFC.jsp");
	});
});
			