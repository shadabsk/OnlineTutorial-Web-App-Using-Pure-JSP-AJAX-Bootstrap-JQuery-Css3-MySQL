$(document).ready(function(){
	$("#subm").click(function(event){
		event.preventDefault(); 
		$('#Contents').show();

		
	});
});