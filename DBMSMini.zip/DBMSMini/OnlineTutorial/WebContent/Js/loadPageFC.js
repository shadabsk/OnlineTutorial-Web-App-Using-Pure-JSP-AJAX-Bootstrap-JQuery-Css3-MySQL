$(document).ready(function(){
	$("#FcPF").on("click",function(){
		$("#content").load("FacultyPF.jsp");
	});
});

$(document).ready(function(){
	$("#FcCR").on("click",function(){
		$("#content").load("FCCRCO.jsp");
	});
});

$(document).ready(function(){
	$("#FcCNT").on("click",function(){
		$("#content").load("FCCRCNT.jsp");
	});
});


			